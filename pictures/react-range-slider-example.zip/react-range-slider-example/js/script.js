class Range extends React.Component {
  constructor(props) {
    super(props);
    this.updateRange = this.updateRange.bind(this);
  }

  updateRange(e) {
    this.props.updateRange(e.target.value);
  }

  render() {
    // console.log(this.props);
    const { range } = this.props;
    return /*#__PURE__*/(
      React.createElement("div", null, /*#__PURE__*/
      React.createElement("input", { id: "range", type: "range",
        value: range,
        min: "0",
        max: "20",
        step: "1",
        onChange: this.updateRange }), /*#__PURE__*/

      React.createElement("span", { id: "output" }, range)));


  }}


class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      rangeVal: 0 };

    this.updateRange = this.updateRange.bind(this);
  }

  updateRange(val) {
    this.setState({
      rangeVal: val });

  }

  render() {
    const { rangeVal } = this.state;
    return /*#__PURE__*/(
      React.createElement(Range, { range: rangeVal, updateRange: this.updateRange }));

  }}


const root = document.getElementById('root');
ReactDOM.render( /*#__PURE__*/React.createElement(App, null), root);